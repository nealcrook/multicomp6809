char clr[2];
main ()
{
    clr[0] = 0x1b;
    clr[1] = 0x3a;
    write (1, clr, 2);    
}


