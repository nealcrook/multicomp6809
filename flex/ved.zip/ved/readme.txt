See flex/VED2.DOC for history and build instructions.
